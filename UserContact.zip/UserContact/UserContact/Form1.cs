﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace UserContact
{
    public partial class Form1 : Form
    {
        public static string path = @"C:\\Users\\Xolani Mnguni\\Desktop\\UserContact\\Contacts.txt";
           public Form1()
        {
            InitializeComponent();
        }
        private void ClearData()
        {
            txtFullName.Clear();
            txtMobile.Clear();
            txtWork.Clear();
            txtEmail.Clear();
        }
        //private void Addlist()
        //{
        //    ListViewItem lvi1 = new ListViewItem();

        //    lvi1.Text = txtFullName.Text.Trim();
        //    listView1.Items.Add(lvi1);
        //}
        private void button1_Click(object sender, EventArgs e)
        {
            ListViewItem lvi1 = new ListViewItem();
            lvi1.Text = txtFullName.Text;
            //lvi1.SubItems.Add(txtMobile.Text.Trim());
            listView1.Items.Add(lvi1);
            if (listView1.Items.Count != 0)
            {
               txtCount.Text =listView1.Items.Count + "Contact(s) in file";
            }
           SaveEvent();
            //Addlist();
        }
        public void SaveEvent()
        {
            DialogResult result;
            result = MessageBox.Show("Do you want to save file?", "Contact", MessageBoxButtons.YesNo, MessageBoxIcon.Question); if (result == DialogResult.No)
            {
                return;
            }
            if (result == DialogResult.Yes)
            {
                try
                {
                    if (txtFullName.Text != null && txtMobile.Text != null && txtWork.Text != null && txtEmail.Text != null)
                    {
                        saveFile(txtFullName.Text , txtMobile.Text, txtWork.Text, txtEmail.Text);
                    }
                }
                catch (Exception err)
                {
                    MessageBox.Show(err.ToString());
                }
                ClearData();
               
            }
        }
        public void saveFile(string FullName, string Mobile, string Work, string Email)
        {
            string Msg = FullName + "\n" + Mobile + "\n" + Work + "\n"+ Email ;

            // Save File to .txt
            FileStream fParameter = new FileStream(path, FileMode.Append, FileAccess.Write);
            StreamWriter m_WriterParameter = new StreamWriter(fParameter);
            m_WriterParameter.BaseStream.Seek(0, SeekOrigin.End);
            m_WriterParameter.Write(Msg+ "\n");
            m_WriterParameter.Flush();
            m_WriterParameter.Close();
        }
        private void btnSearch_Click(object sender, EventArgs e)
        {

            if (txtFullName.Text != "")
            {
                foreach (ListViewItem item in listView1.Items)
                {
                    if (item.Text.ToLower().Contains(txtFullName.Text.ToLower()))
                    {
                        item.Selected = true;
                        txtSearch.Text = "Searching For..." + "\n" + item.ToString() + " in file...." + "\n" + item.ToString() + " was found on Line..." + listView1.Items.Count;
                    }
                    else
                    {
                        listView1.Items.Remove(item);
                        txtSearch.Text = "Searching For..." + "\n" + item.ToString() + "file not found!...";
                    }
                    if (listView1.SelectedItems.Count == 1)
                    {
                        listView1.Focus();
                    }

                }
                ClearData();
            }
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Sure wanna Exit", "Contact?", MessageBoxButtons.OK, MessageBoxIcon.Error);
            this.Close();
        }
       private void Form1_Load(object sender, EventArgs e)
        {
            listView1.View = View.Details;

            listView1.Columns.Add("Full Name");
            //listView1.Columns.Add("Phone");
        }
    }
}

       